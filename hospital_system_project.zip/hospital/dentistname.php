<?php
include("dbconnection.php");




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor details</title>
</head>
<style>
    #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-top: 60px;
        margin-left: 180px;
        padding-right: 150px;
    }

    #customers td,
    #customers th {
        border: 1px solid #ddd;
        padding: 8px;
    }

    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: darkslategray;
        color: white;
    }

    #customers tr:hover {}

    #customers tr:nth-child(even) {
        background-color: #f2f2f2;
    }


    .delete {
        background-color: red;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 25px;

    }

    .confirm {
        background-color: lightseagreen;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 5px;
    }

    .heading {
        text-align: center;
        color: blue;
    }
</style>

<body>
    <?php include("dentistdash.php") ?>
    <div class="heading">
        <h2>PATIENT DETAILS FROM DOCTOR</h2>
    </div>

    <table id="customers">
        <tr>
            <th>#number</th>
            <th>FIRST NAME</th>
            <th>SECOND NAME</th>
            <th>DATE</th>
            <th>ACTION</th>
        </tr>

        <?php
        $count = 1;

        $select_all_patients = "select *
                                 from appointments 
                                 where DoctorType='DENTIST'";

        $result = mysqli_query($conn, $select_all_patients);
        $number = mysqli_num_rows($result);
        if ($number > 0) {
            while ($row = mysqli_fetch_assoc($result)) {  ?>
                <tr>
                    <td><?php echo $count++ ?></td>

                    <td><?php echo $row['firstName']; ?></td>

                    <td><?php echo $row['secondName']; ?></td>

                    <td><?php echo $row['Date']; ?></td>
                    <td>
                        <span><a href="#.php?id=<?php echo $row['id'] ?>"><button type="button" class="confirm">Confirm</button></a></span>
                    </td>
                </tr>
        <?php }
        } else {
            echo "0 results";
        } ?>

    </table>
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#search').keyup(function() {
                search_table($(this).val());

            });

            function search_table(value) {
                $('#customers tr').each(function() {
                    var found = 'false';
                    $(this).each(function() {
                        if ($(this).text().toLowerCase().index(value.toLowerCase()) >= 0) {
                            found = 'true';
                        }
                    });
                    if (found == 'true') {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            }
        });
    </script>
</body>

</html>