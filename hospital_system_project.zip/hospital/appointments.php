<?php
include("dbconnection.php");
session_start();

if (isset($_POST['submit'])) {
    $firstName = $_POST['firstName'];
    $secondName = $_POST['secondName'];
    $DoctorType = $_POST['DoctorType'];
    $Date = $_POST['Date'];

    $appointment_details = "INSERT INTO appointments(firstName, secondName, DoctorType, Date)
        VALUES('$firstName', '$secondName', '$DoctorType', '$Date');";

    if (mysqli_query($conn, $appointment_details)) {
        echo "<script> alert('Appointment aploaded to Doctor')</script>";
        echo "<script>window.location='reception.php'</script>";
    } else {
        echo "Details not sent";
    }
    mysqli_close($conn);
}
