<?php
include("dbconnection.php");
session_start();

if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = md5($_POST['password']);


  $select_reception_detail =
    mysqli_query($conn, "SELECT * FROM `reception` WHERE `email`='$email' AND `password`='$password'");

  $row = mysqli_num_rows($select_reception_detail);

  if ($row > 0) {
    echo "<script> alert('successfully login')</script>";
    echo "<script>window.location='reception.php'</script>";
  } else {
    echo "<script>alert('Invald email or password')</script>";
    echo "<script>window.location='receptlog.php'</script>";
  }
}
