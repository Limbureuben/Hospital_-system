<?php
include("dbconnection.php");
session_start();

if (isset($_POST['signup'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $reception_signup = "INSERT INTO reception (name, email, password)
        VALUES('$name', '$email', '$password');";

    if (mysqli_query($conn, $reception_signup)) {

        echo "<script>window.location='reception.php'</script>";
    } else {
        echo "Failed to signup";
    }
    mysqli_close($conn);
}
