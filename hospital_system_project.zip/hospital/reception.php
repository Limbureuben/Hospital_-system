<?php
include("dbconnection.php");
session_start();
?>

<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>Responsiive Admin Dashboard</title>
  <link rel="stylesheet" href="reception.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class="bx bxl-c-plus-plus"></i>
      <span class="logo_name">RECEPTION</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="#" class="active">
          <i class="bx bx-grid-alt"></i>
          <span class="links_name">Dashboard</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-box"></i>
          <span class="links_name">Apient Registered</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-list-ul"></i>
          <span class="links_name">Available</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-coin-stack"></i>
          <span class="links_name">Dentist</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-book-alt"></i>
          <span class="links_name">Reports</span>
        </a>

      <li>
        <a href="#">
          <i class="bx bx-heart"></i>
          <span class="links_name">SMS</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-cog"></i>
          <span class="links_name">Financial activities</span>
        </a>
      </li>
      <li class="log_out">
        <a href="reclogout.php">
          <i class="bx bx-log-out"></i>
          <span class="links_name">Log-out</span>
        </a>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search..." />
        <i class="bx bx-search"></i>
      </div>
      <div class="profile-details">
        <img src="images/profile.jpg" alt="" />
        <span class="admin_name">Reuben Limbu</span>
        <i class="bx bx-chevron-down"></i>
      </div>
    </nav>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Appointments</div>
            <div class="number">
              <?php
              $countapointments = mysqli_query($conn, "select id from appointments");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>

              <?php } ?>

            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Patient Attended</div>
            <div class="number">0</div>
            <div class="indicator">
              <i class="bx bx-up-arrow-alt"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Available Doctors</div>
            <div class="number">
              <?php
              $countdoctors = mysqli_query($conn, "select id from doctors");
              $totaldoctor = mysqli_num_rows($countdoctors);

              if (empty($totaldoctor) >= 0) { ?>

                <?php echo $totaldoctor; ?>

              <?php } ?>
            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Victims</div>
            <div class="number">0</div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Down From Today</span>
            </div>
          </div>
        </div>
      </div>
      <div class="center">
        <h1>Application</h1>
        <form action="appointments.php" method="post">
          <div class="txt_field">
            <input type="text" name="firstName" required>
            <label>First name</label>
          </div>
          <div class="txt_field">
            <input type="text" name="secondName" required>
            <label>Second name</label>
          </div>
          <select name="DoctorType">
            <option>--CHOOSE DOCTOR---</option>
            <option>MEDICAL DOCTOR</option>
            <option>GENERAL DOCTOR</option>
            <option>DENTIST</option>
            <option>THERAPIST</option>
            <option>RADIOLOGIST</option>
            <option>ALLERGIST</option>
            <option>ORTHOPEDIST</option>
            <option>SURGEON</option>
          </select>
          <div class="txt_field">
            <input type="date" name="Date" required>
          </div>
          <input type="submit" name="submit" value="SUBMIT">
      </div>
    </div>
    </div>
</body>

</html>





</div>
</div>
</section>

<script>
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".sidebarBtn");
  sidebarBtn.onclick = function() {
    sidebar.classList.toggle("active");
    if (sidebar.classList.contains("active")) {
      sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
  };
</script>
</body>

</html>