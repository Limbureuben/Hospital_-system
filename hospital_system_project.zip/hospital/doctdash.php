<?php
include("dbconnection.php");
session_start();

?>

<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>Responsiive Admin Dashboard | CodingLab</title>
  <link rel="stylesheet" href="doctdash.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
  <section class="home-section">
    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic"><a href="generallogin.php">GENERAL DOCTOR</a></div>
            <div class="number">
              <?php
              $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='GENERAL DOCTOR'");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>
              <?php } ?>

            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic"><a href="medicalform.php">MEDICAL DOCTOR</a></div>
            <div class="number">
              <?php
              $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='MEDICAL DOCTOR'");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>
              <?php } ?>
            </div>
            <div class="indicator">
              <i class="bx bx-up-arrow-alt"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic"><a href="dentistform.php">DENTIST</a></div>
            <div class="number">
              <?php
              $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='DENTIST'");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>
              <?php } ?>
            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic"><a href="therapistform.php">THERAPIST</a></div>
            <div class="number">
              <?php
              $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='THERAPIST'");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>
              <?php } ?>
            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Down From Today</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="home">
      <div class="homesec">
        <div class="homethree">
          <div class="box">
            <div class="right-side">
              <div class="box-topic"><a href="radioform.php">RADIOLOGIST</a></div>
              <div class="number">
                <?php
                $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='RADIOLOGIST'");
                $appointments = mysqli_num_rows($countapointments);

                if (empty($appointments) >= 0) { ?>

                  <?php echo $appointments; ?>
                <?php } ?>
              </div>
              <div class="indicator">
                <i class="bx bx-down-arrow-alt down"></i>
                <span class="text">Up from yesterday</span>
              </div>
            </div>
            <i class="bx bx-down-arrow-alt down"></i>
          </div>
          <div class="box">
            <div class="right-side">
              <div class="box-topic"><a href="allegform.php">ALLERGIST</a></div>
              <div class="number">
                <?php
                $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='ALLERGIST'");
                $appointments = mysqli_num_rows($countapointments);

                if (empty($appointments) >= 0) { ?>

                  <?php echo $appointments; ?>
                <?php } ?>
              </div>
              <div class="indicator">
                <i class="bx bx-down-arrow-alt down"></i>
                <span class="text">Up from yesterday</span>
              </div>
            </div>
            <i class="bx bx-down-arrow-alt down"></i>
          </div>
          <div class="box">
            <div class="right-side">
              <div class="box-topic"><a href="orthoform.php">ORTHOPEDIST</a></div>
              <div class="number">
                <?php
                $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='ORTHOPEDIST'");
                $appointments = mysqli_num_rows($countapointments);

                if (empty($appointments) >= 0) { ?>

                  <?php echo $appointments; ?>
                <?php } ?>
              </div>
              <div class="indicator">
                <i class="bx bx-down-arrow-alt down"></i>
                <span class="text">Up from yesterday</span>
              </div>
            </div>
            <i class="bx bx-down-arrow-alt down"></i>
          </div>
          <div class="box"><a href="#"></a>
            <div class="right-side">
              <div class="box-topic"><a href="segioform.php">SURGEON</a></div>
              <div class="number">
                <?php
                $countapointments = mysqli_query($conn, "select id from appointments where DoctorType='SURGEON'");
                $appointments = mysqli_num_rows($countapointments);

                if (empty($appointments) >= 0) { ?>

                  <?php echo $appointments; ?>
                <?php } ?>
              </div>
              <div class="indicator">
                <i class="bx bx-down-arrow-alt down"></i>
                <span class="text">Up from yesterday</span>
              </div>
            </div>
            <i class="bx bx-down-arrow-alt down"></i>
          </div>
        </div>
      </div>
    </div>
</body>

</html>





</div>
</div>
</section>

<script>
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".sidebarBtn");
  sidebarBtn.onclick = function() {
    sidebar.classList.toggle("active");
    if (sidebar.classList.contains("active")) {
      sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
  };
</script>
</body>

</html>