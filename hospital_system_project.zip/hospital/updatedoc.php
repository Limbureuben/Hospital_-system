<?php
include("dbconnection.php");
session_start();

if (isset($_POST["update"])) {
    $firstName = $_POST['firstName'];
    $secondName = $_POST['secondName'];
    $profesion = $_POST['profesion'];
    $date = $_POST['date'];

    $enroll_new_doctor = "INSERT INTO doctors(firstName, secondName, profesion, date)
VALUES('$firstName', '$secondName', '$profesion', '$date');";

    if (mysqli_query($conn, $enroll_new_doctor)) {
        echo "<script> alert('Your details submitted')</script>";
        echo "<script>window.location='Admindash.php'</script>";
    } else {
        echo "your submission denieded";
    }

    mysqli_close($conn);
}

?>





?>