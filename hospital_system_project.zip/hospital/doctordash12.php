<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Responsive Website Homepage HTML and CSS | CodingNepal</title>
  <link rel="stylesheet" href="doctordash11.css" />
</head>

<body>
  <header class="header">
    <nav class="navbar">
      <h2 class="logo">Doctor</h2>
      <input type="checkbox" id="menu-toggle" />
      <label for="menu-toggle" id="hamburger-btn">
        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
          <path d="M3 12h18M3 6h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
        </svg>
      </label>
      <ul class="links">
        <li><a href="doctordash11.php">Home</a></li>
        <li><a href="generaldoctor.php">Patient Details</a></li>
        <li><a href="message.php">Message Admin</a></li>
        <li><a href="#">Profile</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
</body>

</html>