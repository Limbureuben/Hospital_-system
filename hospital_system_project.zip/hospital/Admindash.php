<?php
include("dbconnection.php");
session_start();

?>

<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>Responsive Admin Dashboard</title>
  <link rel="stylesheet" href="admindash.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    #customers {
      font-family: Arial, Helvetica, sans-serif;
      border-collapse: collapse;
      width: 80%;
      margin-top: 40px;
      margin-left: 120px;
      padding-right: 50px;
    }

    #customers td,
    #customers th {
      border: 1px solid #ddd;
      padding: 8px;
    }

    #customers th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: left;
      background-color: darkslategray;
      color: white;
    }

    #customers tr:hover {}

    #customers tr:nth-child(even) {
      background-color: #f2f2f2;
    }


    .delete {
      background-color: red;
      cursor: pointer;
      border-radius: 0px;
      padding: 5px;
      margin-left: 25px;

    }

    .confirm {
      background-color: lightseagreen;
      cursor: pointer;
      border-radius: 0px;
      padding: 5px;
      margin-left: 5px;
    }

    .heading {
      text-align: center;
      color: blue;
    }
  </style>

</head>

<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class="bx bxl-c-plus-plus"></i>
      <span class="logo_name">ADMIN</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="#" class="active">
          <i class="bx bx-grid-alt"></i>
          <span class="links_name">Dashboard</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-box"></i>
          <span class="links_name">Appointments</span>
        </a>
      </li>
      <li>
        <a href="updatedoctor.php">
          <i class="bx bx-list-ul"></i>
          <span class="links_name">Update Doctors</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-box"></i>
          <span class="links_name">Message</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class="bx bx-coin-stack"></i>
          <span class="links_name">Admin profile</span>
        </a>
      </li>
      <li class="log_out">
        <a href="adminlogout.php">
          <i class="bx bx-log-out"></i>
          <span class="links_name">Log-out</span>
        </a>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
        <span class="dashboard">ADMIN DASHBOARD</span>
      </div>
    </nav>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Doctors</div>
            <div class="number">
              <?php
              $countdoctors = mysqli_query($conn, "select id from doctors");
              $totaldoctor = mysqli_num_rows($countdoctors);

              if (empty($totaldoctor) >= 0) { ?>

                <?php echo $totaldoctor; ?>

              <?php } ?>

            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Patients</div>
            <div class="number">
              <?php
              $countapointments = mysqli_query($conn, "select id from appointments");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>

              <?php } ?>

            </div>
            <div class="indicator">
              <i class="bx bx-up-arrow-alt"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Appointments</div>
            <div class="number">

              <?php
              $countapointments = mysqli_query($conn, "select id from appointments");
              $appointments = mysqli_num_rows($countapointments);

              if (empty($appointments) >= 0) { ?>

                <?php echo $appointments; ?>

              <?php } ?>
            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Death</div>
            <div class="number">0</div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text">Down From Today</span>
            </div>
          </div>
        </div>
      </div>
      <table id="customers">
        <tr>
          <th>#number</th>
          <th>FIRST NAME</th>
          <th>SECOND NAME</th>
          <th>DOCTOR</th>
          <th>DATE</th>
          <th>ACTION</th>
        </tr>

        <?php
        $count = 1;

        $select_all_users = "select * from appointments";

        $result = mysqli_query($conn, $select_all_users);
        $number = mysqli_num_rows($result);
        if ($number > 0) {
          while ($row = mysqli_fetch_assoc($result)) {  ?>
            <tr>
              <td><?php echo $count++ ?></td>

              <td><?php echo $row['firstName']; ?></td>

              <td><?php echo $row['secondName']; ?></td>

              <td><?php echo $row['DoctorType']; ?></td>

              <td><?php echo $row['Date']; ?></td>
              <td>
                <span><a href="confirmappointment.php?id=<?php echo $row['id'] ?>"><button type="button" class="confirm">Update</button></a></span>
                <span><a href="deleteappointment.php?id=<?php echo $row['id'] ?>"><button type="button" class="delete">Delete</button></a></span>
              </td>
            </tr>
        <?php }
        } else {
          echo "0 results";
        } ?>

      </table>








    </div>
    </div>
  </section>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    };
  </script>

</body>



</html>