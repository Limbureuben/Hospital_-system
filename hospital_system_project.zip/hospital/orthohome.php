<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>dentist-dashboard</title>
  <link rel="stylesheet" href="orthohome.css">
  <!-- Fontawesome Link for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
  <?php include("orthodash.php")  ?>
  <section class="homepage" id="home">
    <div class="content">
      <div class="text">
        <h1>#Limbu Academy & Hospital</h1>
        <p>
          This is an hospital, staffed and equipped for the diagnosis of desiase.<br>
          For the treatment of both medical and surgical of the sick and
          the injured and for their housing during this process.
        </p>
      </div>
      <a href="#services">Our Services</a>
    </div>
  </section>
</body>

</html>