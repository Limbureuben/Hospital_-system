<?php
include("dbconnection.php");

$id = $_REQUEST['id'];
$query_for_select_user_row = "DELETE FROM appointments WHERE id= $id";

$result = mysqli_query($conn, $query_for_select_user_row);

header("Location:Admindash.php");
exit();
