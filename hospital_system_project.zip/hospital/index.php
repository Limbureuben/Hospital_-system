<?php
include("dbconnection.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="index.css">
</head>

<body>
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">....</h2>
            </div>
            <div class="menu">
                <ul>
                    <li><a href="receptlog.php">RECEPTION</a></li>
                    <li><a href="phamac.php">PHARMACY</a></li>
                    <li><a href="doctdash.php">DOCTORS</a></li>
                    <li><a href="adminlog.php">ADMIN</a></li>
                    <li><a href="contactus.php">CONTACT</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="content">
            <h1><span>Welcome Limbu Academy & Hospital,</span><br>You can
                visit our website</h1>
            <p div class="par">
                #Master company already desgned & developed a number of system
                <br> If you are interested to be together with us click Join-us button<br>
                so just join us to vist our website for more information.
            </p>
            <button class="cn"><a href="#">JOIN US</a></button>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <script src="https://unpkg.com/ionics@5.4.0/dist/ionicons.js"></script>
</body>

</html>