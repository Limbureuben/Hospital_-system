<?php
include("dbconnection.php");
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>appointments</title>
</head>
<style>
    #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-top: 170px;
        margin-left: 261px;
        padding-right: 50px;
    }

    #customers td,
    #customers th {
        border: 1px solid #ddd;
        padding: 8px;
    }

    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: darkslategray;
        color: white;
    }

    #customers tr:hover {}

    #customers tr:nth-child(even) {
        background-color: #f2f2f2;
    }


    .delete {
        background-color: red;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 25px;

    }

    .update {
        background-color: lightseagreen;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 5px;
    }

    .heading {
        text-align: center;
        color: blue;
    }
</style>

<body>
    <table id="customers">
        <tr>
            <th>#number</th>
            <th>FIRST NAME</th>
            <th>SECOND NAME</th>
            <th>DOCTOR</th>
            <th>DATE</th>
            <th>ACTION</th>
        </tr>

        <?php
        $count = 1;

        $select_all_users = "select * from appointments";

        $result = mysqli_query($conn, $select_all_users);
        $number = mysqli_num_rows($result);
        if ($number > 0) {
            while ($row = mysqli_fetch_assoc($result)) {  ?>
                <tr>
                    <td><?php echo $count++ ?></td>

                    <td><?php echo $row['firstName']; ?></td>

                    <td><?php echo $row['secondName']; ?></td>

                    <td><?php echo $row['DoctorType']; ?></td>

                    <td><?php echo $row['Date']; ?></td>
                    <td>
                        <a href="updation.php?id=<?php echo $row['id'] ?>"><button type="button" class="update">Update</button></a>
                        <span><a href="deleteuser.php?id=<?php echo $row['id'] ?>"><button type="button" class="delete">Delete</button></a></span>
                    </td>
                </tr>
        <?php }
        } else {
            echo "0 results";
        } ?>

    </table>
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#search').keyup(function() {
                search_table($(this).val());

            });

            function search_table(value) {
                $('#customers tr').each(function() {
                    var found = 'false';
                    $(this).each(function() {
                        if ($(this).text().toLowerCase().index(value.toLowerCase()) >= 0) {
                            found = 'true';
                        }
                    });
                    if (found == 'true') {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            }
        });
    </script>
</body>

</html>