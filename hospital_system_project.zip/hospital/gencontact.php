<?php
include("dbconnection.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>contact-us</title>
  <link rel="stylesheet" type="text/css" href="gencontact.css">
</head>

<body>
  <?php include("gendash.php") ?>
  <section class="contact" id="contact">
    <h2>Contact Us</h2>
    <p>Reach out us for any inquiries or feedback.</p>
    <div class="row">
      <div class="col information">
        <div class="contact-details">
          <p><i class="fas fa-map-marker-alt"></i> 123 Campsite Avenue, Wilderness, CA 98765</p>
          <p><i class="fas fa-envelope"></i> limbureubenn@gmail.com</p>
          <p><i class="fas fa-phone"></i> +2556-2521-9727</p>
          <p><i class="fas fa-clock"></i> Monday - Friday: 9:00 AM - 5:00 PM</p>
          <p><i class="fas fa-clock"></i> Saturday: 10:00 AM - 3:00 PM</p>
          <p><i class="fas fa-clock"></i> Sunday: Closed</p>
          <p><i class="fas fa-globe"></i> www.reubenlimbu.com</p>
        </div>
      </div>
      <div class="col form">
      </div>
    </div>
  </section>

</body>

</html>