<?php
include_once "dbconnection.php";

if (isset($_POST["general_details"])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $website = $_POST['website'];
    $message = $_POST['message'];


    $insert_dentist = "INSERT INTO generaldetails (name, email, phone, website, message)
    VALUES('$name', '$email', '$phone', '$website', '$message');";


    if (mysqli_query($conn,  $insert_dentist)) {

        echo "<script> alert('your message submitted')</script>";
        echo "<script>window.location='genhome.php'</script>";
    } else {
        echo "message not submited";
    }

    mysqli_close($conn);
}
