<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dentist</title>
  <link rel="stylesheet" href="radiodash.css">
  <!-- Fontawesome Link for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
  <header>
    <nav class="navbar">
      <h2 class="logo"><a href="radiologout.php">Log-out</a></h2>
      <input type="checkbox" id="menu-toggler">
      <label for="menu-toggler" id="hamburger-btn">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24px" height="24px">
          <path d="M0 0h24v24H0z" fill="none" />
          <path d="M3 18h18v-2H3v2zm0-5h18V11H3v2zm0-7v2h18V6H3z" />
        </svg>
      </label>
      <ul class="all-links">
        <li><a href="radiohome.php">Home</a></li>
        <li><a href="radioname.php">Patient name</a></li>
        <li><a href="radiopatient.php">Patient Details</a></li>
        <li><a href="radiomessage.php">Message Admin</a></li>
        <li><a href="radiocontact.php">Contact-us</a></li>
      </ul>
    </nav>
  </header>
</body>

</html>