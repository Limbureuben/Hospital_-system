<?php
include("dbconnection.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>home</title>
  <link rel="stylesheet" href="phamacdash.css">
</head>

<body>
  <?php include("phamacdashboard.php") ?>
  <section class="homepage" id="home">
    <div class="content">
      <div class="text">
        <h1>#Limbu Academy & Hospital</h1>
        <p>
          This is an hospital, staffed and equipped for the diagnosis of desiase.<br>
          For the treatment of both medical and surgical of the sick and
          the<br> injured and for their housing during this process.
      </div>
      <a href="#services">Our Services</a>
    </div>
  </section>
</body>

</html>